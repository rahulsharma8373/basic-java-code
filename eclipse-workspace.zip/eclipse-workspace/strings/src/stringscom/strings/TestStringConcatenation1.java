package stringscom.strings;

public class TestStringConcatenation1 {
public static void main(String[] args) {
	String s="sachin "+"tendulkar";
	System.out.println(s);
}
}
