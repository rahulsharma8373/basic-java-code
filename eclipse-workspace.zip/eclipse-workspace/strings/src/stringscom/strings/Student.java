package stringscom.strings;

public class Student {
int rollno;
String name;
String city;

public Student(int rollno, String name, String city) {
	super();
	this.rollno = rollno;
	this.name = name;
	this.city = city;
}

@Override
public String toString() {
	return "Student [rollno=" + rollno + ", name=" + name + ", city=" + city + "]";
}

public static void main(String[] args) {
	Student s1=new Student(101,"rekha","lucknow");
	Student s2=new Student(102,"kundan","noida");
	Student s3=new Student(103,"pooja","patna");
	Student s4=new Student(104,"shyam","delhi");
	
	System.out.println(s1);
	System.out.println(s2);
	System.out.println(s3);
	System.out.println(s4);
}


}


