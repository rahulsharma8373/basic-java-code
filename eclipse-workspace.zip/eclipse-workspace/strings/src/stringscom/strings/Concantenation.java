package stringscom.strings;

public class Concantenation {
public static void main(String[] args) {
	String s = "rahul";
	String w = "sharma";
	String d = s.concat(w);
	System.out.println(d);
	
}
}
