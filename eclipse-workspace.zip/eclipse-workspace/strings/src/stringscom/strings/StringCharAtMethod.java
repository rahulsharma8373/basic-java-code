package stringscom.strings;

public class StringCharAtMethod {
public static void main(String[] args) {
	String s = "Sachin";
	System.out.println(s.charAt(0));
	System.out.println(s.charAt(3));
}
}
