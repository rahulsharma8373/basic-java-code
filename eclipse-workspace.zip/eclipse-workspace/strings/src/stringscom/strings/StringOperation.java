package stringscom.strings;

public class StringOperation {
public static void main(String[] args) {
	String s = "sachin";
	System.out.println(s.toUpperCase());
	System.out.println(s.toLowerCase());
	System.out.println(s);
}
}
