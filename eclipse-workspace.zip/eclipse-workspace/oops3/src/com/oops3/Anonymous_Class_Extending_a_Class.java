package com.oops3;
class Rahul{
	public void show() {
		System.out.println("inside the polygon class");
	}
}
class AnonymousDemo{
	public void createClass() {
		
	
	// creation of anonymous class extending class Rahul
	Rahul r1=new Rahul() {
	public void show() {
		System.out.println("inside an anonymous class"); 
	}
	};
	r1.show();
}
}
public class Anonymous_Class_Extending_a_Class {
	public static void main(String[] args) {
	
	AnonymousDemo an = new AnonymousDemo();
	an.createClass();
	}

}
