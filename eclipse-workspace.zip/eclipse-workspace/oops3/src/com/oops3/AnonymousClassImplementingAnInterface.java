package com.oops3;
interface Polygon{
	public void show(); 
}
class anonymousDemo{
	public void CreateClass() {
		// anonymous class implementing interface
		Polygon p1 = new Polygon() {
			@Override
			public void show() {
				// TODO Auto-generated method stub
				System.out.println("Inside an anonymous class");
			}
			
		};
		p1.show();
}
public class AnonymousClassImplementingAnInterface {
	public void main(String[] args) {
	AnonymousDemo an = new AnonymousDemo();
	an.createClass();

	}
}}
