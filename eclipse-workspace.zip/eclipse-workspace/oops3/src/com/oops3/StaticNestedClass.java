package com.oops3;

import com.oops3.Animal.mammal1;

class Animal{
	class Reptile{
		public void show() {
			System.out.println("I am reptile");
		}
	}
	static class mammal1{
		public void show() {
			System.out.println("I am mammal");
		}
	}
}
public class StaticNestedClass {
	public static void main(String[] args) {
	Animal animal=new Animal();
	Animal.Reptile reptile=animal.new Reptile();
	reptile.show();
	// object creation of the static nested class
	Animal.mammal1 mammal=new mammal1();
	mammal.show();
	}
}
// only nested classes can be static
// we cannot access non-static methods from static classes