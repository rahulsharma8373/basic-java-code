package somethingelse;

public class DuplicateCharInStrings {

	public static void main(String[] args) {
	/* 
	String str="programming";
		
		// approach1.  using java 8
		StringBuilder sb1= new 	StringBuilder();
		str.chars().distinct().forEach(c -> sb1.append((char)c));
System.out.println(sb1);

*/

		/* 
			int x = 10;    
			int y = 12;    
			if(x+y > 20) {    
			System.out.println("x + y is greater than 20");    
			}    
			*/
			/*
			int x = 10;  
			int y = 12;  
			if(x+y < 10) {  
			System.out.println("x + y is less than      10");  
			}   else {  
			System.out.println("x + y is greater than 20");  
			}  	
			*/
		/*	
		String city = "Delhi";  
		if(city == "Meerut") {  
		System.out.println("city is meerut");  
		}else if (city == "Noida") {  
		System.out.println("city is noida");  
		}else if(city == "Agra") {  
		System.out.println("city is agra");  
		}else {  
		System.out.println(city);  
		
		
		
		}
		*/
		
		
		int sum = 0;  
		for(int j = 1; j<=10; j++) {  
		sum = sum + j;  
		}  
		System.out.println("The sum of first 10 natural numbers is " + sum);  
		
		
		String[] names = {"Java","C","C++","Python","JavaScript"};    
		System.out.println("Printing the content of the array names:\n");    
		for(String name:names) {    
		System.out.println(name);    
		}  
		
		int i = 0;    
		System.out.println("Printing the list of first 10 even numbers \n");    
		while(i<=10) {    
		System.out.println(i);    
		i = i + 2;    
		
		}
		
		
		int i1 = 0;    
		System.out.println("Printing the list of first 10 even numbers \n");    
		do {    
		System.out.println(i);    
		i = i + 2;    
		} while(i<=10); 
	}
}
		     
		




	
