package com.java;

public class TryCatch3 {

	public static void main(String[] args) {
		try {
			int data =  50/0;
		}catch(Exception b) {
			System.out.println(b);
		}
		System.out.println("rest of the code");
	}

}
