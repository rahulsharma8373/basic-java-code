package com.java;

public class TryCatchExample {

	public static void main(String[] args) {
		
		try  
        {  
        int t=50/0; //may throw exception   
        }  
            //handling the exception  
        catch(ArithmeticException a)  
        {  
            System.out.println(a);  
        }  
        System.out.println("rest of the code");  
    }  
      
}  
		
		
		
	
