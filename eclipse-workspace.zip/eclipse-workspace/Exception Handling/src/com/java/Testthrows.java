package com.java;
//Case 1: We have caught the exception i.e. we
//have handled the exception using try/catch block.
//Que) Can we rethrow an exception?
//Yes, by throwing same exception in catch block
import java.io.IOException;

 class M {

	void method() throws IOException{
		throw new IOException("device error");
	}
}
	public class Testthrows{
	public static void main(String[] args) {
		
		try {
			M m=new M();
			m.method();
		}catch(Exception e) {
			System.out.println("exception handled");
		}
		
System.out.println("normal flow..");

	}

}
