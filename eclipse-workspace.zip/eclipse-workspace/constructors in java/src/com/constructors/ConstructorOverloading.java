package com.constructors;
class Geek3
{
    // constructor with one argument
    Geek3(String name)
    {
        System.out.println("Constructor with one " +
                      "argument - String : " + name);
    }
 
    // constructor with two arguments
    Geek3(String name, int age)
    {
 
        System.out.println("Constructor with two arguments : " +
                " String and Integer : " + name + " "+ age);
 
    }
 
    // Constructor with one argument but with different
    // type than previous..
    Geek3(long id)
    {
        System.out.println("Constructor with one argument : " +
                                            "Long : " + id);
    }
}
 
public class ConstructorOverloading {

	public static void main(String[] args) {
    
        // Creating the objects of the class named 'Geek'
        // by passing different arguments
 
        // Invoke the constructor with one argument of
        // type 'String'.
        Geek3 geek2 = new Geek3("Shikhar");
 
        // Invoke the constructor with two arguments
        Geek3 geek4 = new Geek3("Dharmesh", 26);
 
        // Invoke the constructor with one argument of
        // type 'Long'.
        Geek3 geek5 = new Geek3(325614567);
    }
}
