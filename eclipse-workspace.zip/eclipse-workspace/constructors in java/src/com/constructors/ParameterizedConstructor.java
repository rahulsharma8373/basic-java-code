package com.constructors;
//Java Program to Illustrate Working of
//Parameterized Constructor
class Rahul{
	String name;
	int id;
	// Constructor would initialize data members
    // With the values of passed arguments while
    // Object of that class created
	Rahul(String name,int id){
		this.name = name;
		this.id = id;
	}
	
	
	}

public class ParameterizedConstructor {
	public static void main(String[] args) {
		Rahul raj=new Rahul("Sharma",1);
		System.out.println("[RahulName] :" + raj.name +  "[ RahulId ]:  " + raj.id   );
	}

}
