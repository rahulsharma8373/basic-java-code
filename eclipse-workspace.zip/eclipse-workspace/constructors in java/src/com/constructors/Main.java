package com.constructors;

public class Main {
String language;
// constructor accepting single values
Main(String lang){
	String languages = lang;
	System.out.println(languages + "programming languages");
	
}
public static void main(String[] args) {
	// call constructor by passing a single value
	Main obj1=new Main("java");
	Main obj2=new Main("python");
	Main obj3=new Main("c");
}
}
