package com.Abstract.method;
/*
 * If the abstract class includes any abstract method,
 *  then all the child classes inherited from the abstract
 *   superclass must provide the
 *  implementation of the abstract method. 
 */

abstract class Animal{
	abstract void makesound();
	public void eat() {
		System.out.println("I can eat");
	}
}
class Dog extends Animal{
	// provide implementation of abstract class
	@Override
	void makesound() {
	System.out.println("Bark bark");
		
	}
	 
}
public class Implementing_Abstract_Methods {
	public static void main(String[] args) {
	Dog  d=new Dog();
	d.makesound();
	d.eat();
	}

}
