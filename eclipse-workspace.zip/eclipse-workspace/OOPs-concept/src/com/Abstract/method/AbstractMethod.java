package com.Abstract.method;
/*
 * If a class contains an abstract method, then the class 
 * should be declared abstract. Otherwise, it will generate
 *  an error. 
 *  For example,
// error
// class should be abstract
class Language {

  // abstract method
  abstract void method1();
}
 */

abstract class Language{
	public void display() {
		System.out.println("This is java Programming");
	}
}

public class AbstractMethod extends Language {
	public static void main(String[] args) {
		AbstractMethod a=new AbstractMethod ();
		a.display();
	}
}
