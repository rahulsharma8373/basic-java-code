package com.interfaces;

// why interfaces
// to achieve abstraction in java
// provide specifications
// used to achieve multiple inheritance in java
/*
 * interface Line {
�
}

interface Polygon {
�
}

class Rectangle implements Line, Polygon {
�
}



Note: All the methods inside an interface are implicitly public and all fields are implicitly public static final. For example,

interface Language {
  
  // by default public static final
  String type = "programming language";

  // by default public
  void getName();
}
 */



/*
 * Implementing Multiple Interfaces
In Java, a class can also implement multiple interfaces. For example,

interface A {
  // members of A
}

interface B {
  // members of B
}

class C implements A, B {
  // abstract members of A
  // abstract members of B
}


 interfaces can extend other interfaces. 
 The extends keyword is
  used for extending interfaces
  
  
  Extending Multiple Interfaces
An interface can extend multiple interfaces. For example,

interface A {
   ...
}
interface B {
   ... 
}

interface C extends A, B {
   ...
}
 */
interface  Language{
	void getname(String name);

}
class ProgrammingLanguage implements Language{

	@Override
	public void getname(String name) {
		System.out.println("Programming Language; " + name);
	}
	
}

public class Java_Interface {
public static void main(String[] args) {
	 ProgrammingLanguage p = new  ProgrammingLanguage();
	 p.getname("java");
}
}
