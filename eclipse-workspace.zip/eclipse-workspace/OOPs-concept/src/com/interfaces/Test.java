package com.interfaces;
/*
 * An interface is a fully abstract class. 
 * It includes a group of abstract methods 
 * (methods without a body).
We use the interface keyword to create an interface 
in Java


for example 
interface Language {
  public void getType();

  public void getVersion();
}
 */
interface Polygon{
	void getArea(int length, int breadth);
	
}

// implements the polygon interfaces
class Rectangle implements Polygon{

	@Override
	public void getArea(int length, int breadth) {
		System.out.println("the areaa of rectangle is = " + (length*breadth));
	}
	
}


public class Test {
	public static void main(String[] args) {
		Rectangle r=new Rectangle();
		r.getArea(5, 4);
	}

}
