package com.interfaces;
// default method in java interfaces

interface Polygon1{
	void getarea();
	// default method
	default void getSides()
{
		System.out.println("i can get sides of a polygon");
		
}
}
class Rectangle1 implements Polygon1{

	@Override
	public void getarea() {
		
int breadth=9;
int length=9;
int area=length*breadth;
System.out.println("the area of rectangle is "+ area);
	}
	
	public void getSides() {
		System.out.println("i have 4 sides");
	}
}
class Sqaure implements Polygon1{

	

	@Override
	public void getarea() {
		
	int length=5;
	int breadth=7;
	int area=length*breadth;
	System.out.println("the area of square is " + area );	
	}
	
}
public class Default_Methods {
public static void main(String[] args) {
	Rectangle1 r=new Rectangle1();
	r.getarea();
	r.getSides();
	Sqaure s=new Sqaure();
	s.getarea();
	s.getSides();
}
}
/*
 * private and static Methods in Interface
The Java 8 also added another feature to include static methods inside an interface.

Similar to a class, we can access static methods of an interface using its references. For example,

// create an interface
interface Polygon {
  staticMethod(){..}
}

// access static method
Polygon.staticMethod();


Note: With the release of Java 9, private methods are
 also supported in interfaces.

We cannot create objects of an interface. 
Hence, private methods are used as helper methods
 that provide support to
 other methods in interfaces.
 */
*/