package com.inheritance;

class Animal1{
	public void eat() {
		System.out.println(" I can eat");
	}
}
class Dog1 extends Animal{
	// overriding the eat method
	@Override
	public void eat() {
		System.out.println(" I eat  dog food");
	}
	public void bark() {
		System.out.println(" i can bark");
	}
}

public class Method_Overriding_In_Java_Inheritance {

	public static void main(String[] args) {
		Dog1 d = new Dog1();
		d.eat();
		d.bark();
		

	}

}
