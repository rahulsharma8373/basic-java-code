package com.inheritance;
class Animal2{
	public void eat() {
		System.out.println("i can eat");
	}
}
class Cow extends Animal2{
	public void eat() {
		
	// call method of super class
		super.eat();
		System.out.println("i eat cow food");
	}
	public void bark() {
		System.out.println(" i can bark");
	}
}
public class Super_Keyword_InInheritance {
	public static void main(String[] args) {
		// create  an object of the subclass 
Cow c=new Cow();
c.bark();
c.eat();
c.bark();
	}
}
