/*
Why use inheritance?
The most important use of inheritance 
in Java is code reusability. The code that is
present in the 
parent class can be directly used
by the child class.
Method overriding is also known as runtime 
polymorphism. Hence, we can achieve Polymorphism 
in Java with the help of inheritance.  
*/


package com.inheritance;
class Animal{
	String name;
	public void eat() {
		System.out.println(" i can eat");
	}}

	class Dog extends Animal{
		public void display() {
			System.out.println("my name is "  + name);
		
		
	}
}

public class Main {
public static void main(String[] args) {
	Dog d = new Dog();
	d.name="pet";
	d.eat();
	d.display();
	
}
}
