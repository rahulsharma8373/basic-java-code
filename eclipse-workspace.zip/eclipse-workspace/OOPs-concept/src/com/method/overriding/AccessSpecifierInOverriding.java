package com.method.overriding;
/*
 * Access Specifiers in Method Overriding
The same method declared in the superclass and its
 subclasses can have different access specifiers.
  However, there is a restriction.
We can only use those access specifiers in subclasses
 that provide larger access than the access specifier of the
  superclass. 
  For example,
Suppose, a method myClass() in the superclass is
 declared protected. Then, the same method myClass() in 
 the subclass can be either public or protected,
 but not private.
 */
class Animal1{
	protected void displayInfo() {
		System.out.println("i am an dog");
	}
}
class Dog1 extends Animal1{
	public void Display() {
		System.out.println(" i am a dog");
	}
}

public class AccessSpecifierInOverriding {
	public static void main(String[] args) {
	
Dog1 d1=new Dog1();
d1.displayInfo();
	}

}
