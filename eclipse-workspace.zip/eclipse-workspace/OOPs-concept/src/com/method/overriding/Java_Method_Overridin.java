package com.method.overriding;
/*
 * if the same method is defined in both the superclass
 *  and the subclass, then the method of the subclass
 *   class overrides the method of the superclass.
 *  This is known as method overriding.
 *  
 *  
 *  
 *  It is important to note that constructors in Java are
 *   not inherited. Hence, there is no such thing as 
 *   constructor overriding in Java.
 */

class Animal{
	public void eat() {
		System.out.println("aniaml");
	}
}
class Dog extends Animal{
	public void eat() {
		System.out.println("dog");
	}
}

public class Java_Method_Overridin {
	public static void main(String[] args) {
	Dog d=new Dog();
	d.eat();
	}

}
