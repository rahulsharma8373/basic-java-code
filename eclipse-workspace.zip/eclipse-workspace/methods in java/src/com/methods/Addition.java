package com.methods;

public class Addition {
	public static void main(String[] args) {
		
	int n1=19;
	int n2=5;
	int s3=n1+n2;
	System.out.println(s3);
	
	}

}
