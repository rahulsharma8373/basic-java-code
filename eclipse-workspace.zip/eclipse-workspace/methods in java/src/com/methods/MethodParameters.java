package com.methods;

public class MethodParameters {
// method with no parameter
	public void display1() {
		System.out.println("method without parameter");
	}
	// method with single parameter
	public void display2(int a) {
		System.out.println("method with a single parameter: " + a);
	}
	 public static void main(String[] args) {
		 
		 MethodParameters obj = new MethodParameters();
		 obj.display1();
		 obj.display2(23);
		
	 }
	
}
