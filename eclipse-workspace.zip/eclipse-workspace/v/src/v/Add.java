package v;

public class Add {
	public static void main(String[] args) {
int a=2;
int b=4;
int resykt =a+b;
System.out.println(resykt);

}
}