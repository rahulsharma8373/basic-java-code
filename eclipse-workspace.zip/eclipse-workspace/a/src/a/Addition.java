package a;

public class Addition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int q=100000000;
int j=10000000;
int c=q+j;
System.out.println(c);
	}

}
