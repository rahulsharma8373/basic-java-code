package t;

import java.util.ArrayList;

public class IterateThroughAnArraylist {

	public static void main(String[] args) {
		ArrayList<String> animal = new ArrayList<>();
		animal.add("dog");
		animal.add("cow");
		animal.add("cat");
		for(String ani : animal) {
			System.out.print(ani);
		}
		
		
		
	}

	
}
