package t;

import java.util.Stack;

public class Mainnnn {
public static void main(String[] args) {
	Stack<String> animal=new Stack<>();
	animal.push("dog");
	animal.push("cat");
	animal.push("cow");
	System.out.println(animal);
	boolean result =animal.empty();
	System.out.println(result);
}
}
 