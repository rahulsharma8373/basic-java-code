package t;

import java.util.ArrayList;
import java.util.List;

public class ArrayListClass {
public static void main(String[] args) {
	// creating list using array list using arraylist class
	List<Integer> num = new ArrayList<>();
	num.add(1);
	num.add(2);
	num.add(3);
	System.out.println(num);
	
	// Access elements from  the list
	int removedNumber=num.remove(1);
	System.out.println(removedNumber);
}
}
