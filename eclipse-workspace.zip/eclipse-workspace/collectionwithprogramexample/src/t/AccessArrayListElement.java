package t;

import java.util.ArrayList;

public class AccessArrayListElement {

	public static void main(String[] args) {
		ArrayList<String> animals=new ArrayList<>();
		animals.add("Dog");
		animals.add("cat");
		animals.add("cow");
		System.out.println(animals);
		
		
		
		// get the elements from the arraylist
		String str=animals.get(1);
		System.out.println(str);
	}

}
