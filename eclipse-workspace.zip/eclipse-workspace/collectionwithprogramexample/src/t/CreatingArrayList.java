package t;

import java.util.ArrayList;

public class CreatingArrayList {
public static void main(String[] args) {
	ArrayList<String> languages= new ArrayList<>();
	languages.add("python");
	languages.add("ruby");
	languages.add("springboot");
	System.out.println(languages);
	
	
	// change the elements arrayList 
	 languages.set(1, "c++");
	System.out.println(languages);
}
}
