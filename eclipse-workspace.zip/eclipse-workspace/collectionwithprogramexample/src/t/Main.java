package t;

import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		ArrayList<String> a=new ArrayList<>();
		a.add("cat");
		a.add("dog");
		a.add("cow");
		System.out.println(a);
	}
}
