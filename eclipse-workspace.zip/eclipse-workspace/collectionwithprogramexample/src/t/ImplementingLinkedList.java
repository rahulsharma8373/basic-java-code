package t;

import java.util.LinkedList;
import java.util.List;

public class ImplementingLinkedList {

	public static void main(String[] args) {
		List<Integer> numbers  = new LinkedList<>();
		
		numbers.add(1);
		numbers.add(2);
		numbers.add(3);
		System.out.println(numbers);

		// access elements from the list
		//int num=numbers.get(2);
	//	System.out.println(num);
		
		// using the index of method
		int  num=numbers.indexOf(2);
		System.out.println(num);
		// remove elements from the list
		int nnumber= numbers.remove(1);
		System.out.println(nnumber);
	}

}
