package t;

import java.util.PriorityQueue;
import java.util.Queue;

public class priorityQueue {

	public static void main(String[] args) {
	Queue<Integer> numbers = new PriorityQueue<>();
// offer element to the queue
	numbers.offer(1);
	numbers.offer(2);
	numbers.offer(3);
	numbers.offer(4);
	numbers.offer(5);
	numbers.offer(6);
	System.out.println(numbers);
	  int accessedNumber = numbers.peek();
	  System.out.println(accessedNumber);
	  int removedNumber = numbers.poll();
	  System.out.println(removedNumber);
	}

}
