package t;

import java.util.LinkedList;
import java.util.List;

public class LinkedListClass {

	public static void main(String[] args) {
		
	//creating list using linkedlist class
		List<Integer> numbers = new LinkedList<>();
		

	}

}
