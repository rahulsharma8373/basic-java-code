package t;

abstract class Vehicle{
	abstract void run();
}
class Car extends Vehicle{
	void run() {
		System.out.println("car start with key");
	}
}
class Gun extends Vehicle{
	void run() {
		System.out.println("gun start with kick");
	}
}


public class Abstract {
	public static void main(String[] args) {
		Car c=new Car();
		c.run();
		Gun g=new Gun();
		g.run();
				

	}

}
