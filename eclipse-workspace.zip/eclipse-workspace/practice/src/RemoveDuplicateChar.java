
public class RemoveDuplicateChar {
	public static void main(String[] args) {
		String s="ccooddiinngg";
		System.out.println("old char : "+s);
		System.out.println("new char : "+removeDuplicateChar(s));
	}
	public static String removeDuplicateChar(String s) {
	String news="";
	for(int i=0;i<s.length();i++) {
		char ch=s.charAt(i);
		if(news.indexOf(ch)==-1) {
			news=news+ch;
		}
	}
		return news;
	}
}

