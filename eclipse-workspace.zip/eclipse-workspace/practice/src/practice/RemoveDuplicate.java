package practice;

public class RemoveDuplicate {

	public static void main(String[] args) {
		String str="aabccddb";
		// using java 8
StringBuilder sb1=new StringBuilder();
		str.chars().distinct().forEach(c -> sb1.append((char)c));
		System.out.println(sb1);
		
		
		
		
		
		
		
		
	}

}
