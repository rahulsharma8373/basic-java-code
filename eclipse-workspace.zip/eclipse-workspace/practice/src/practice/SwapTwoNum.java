package practice;

public class SwapTwoNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=1;
int b=2;
System.out.println("before swaping values: " +a+" "+b);
		
		// without using third variable
		a=a+b; // 3
		b=a-b; // 1
		a=a-b; // 2
		System.out.println("After swaping values: " +a+" "+b);
	}

}
