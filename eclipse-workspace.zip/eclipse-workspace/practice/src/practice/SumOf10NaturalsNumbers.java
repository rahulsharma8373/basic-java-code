package practice;

public class SumOf10NaturalsNumbers {

	public static void main(String[] args) {
	
		//natural no= 1,2,3,4,5,6,7,8,9,10 find sum of this
	int	num=10;
		int i;
		int sum=0;
for( i=1;i<=num;i++) {
	 sum=sum+i;
}
	System.out.println("Sum of 10 natural numbers is: " +sum);	
		
		
	}

}
