package practice;

public class SwapTwoNumbers {

	public static void main(String[] args) {
	// a=10, b=20
		int a=10;
		int b=20;
		System.out.println("Before swaping values are:    " +a+ ", "+ b);
		a=a+b; // a=30
		b=a-b; //b=10
		a=a-b; //a=20
		System.out.println("After swaping:    " +a+" ,"+ b);
		
		
	}

}
