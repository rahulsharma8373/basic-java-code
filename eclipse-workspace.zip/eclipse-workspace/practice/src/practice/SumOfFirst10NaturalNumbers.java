package practice;

public class SumOfFirst10NaturalNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int i, sum=0, num=10;
for( i=1;i<=10;i++) {
	sum=sum+i;
}
		System.out.println("Sum of first 10 natural numbers: " +sum);
		
		
		
		
	}

}
