package practice;

public class ReverseSsstring {

	public static void main(String[] args) {
		String str1="Rahul";
		StringBuffer br=new StringBuffer(str1);
		System.out.println(br.reverse());
		
	}

}
