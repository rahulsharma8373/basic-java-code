package com.psractice;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {
		// 1234
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a number");
		int s= sc.nextInt();
	
		while(s>0) {
			int digit=s%10;
			s=s/10;
			System.out.print(digit);
		}
		
	}

}
