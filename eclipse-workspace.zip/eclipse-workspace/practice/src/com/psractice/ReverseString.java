package com.psractice;

public class ReverseString {

	public static void main(String[] args) {
		// by the logic with the help of for loop
		// rahul ko reverse karna hain
		String str ="Rahul";
	String	rev=" ";
	int len=str.length();    // 5
	for(int i=len-1;i>=0;i--) { 
		rev=rev+str.charAt(i);
		
	}
	
	System.out.println(rev);

	}

}
