package com.psractice;

public class RemoveDuplicateString {

	public static void main(String[] args) {
		
	String str="raahhull";
		 System.out.println("old string is : "+str);
		System.out.println("new String is : "+removeDuplicateChar(str));
		
		
	}

	public static String removeDuplicateChar(String str) {
		String newStr="";
		for(int i=0;i<str.length();i++) {
			char ch=str.charAt(i);
			if(newStr.indexOf(ch)==-1) {
				newStr=newStr+ch;
			}
		}
		return newStr;
	
	}
	
}
