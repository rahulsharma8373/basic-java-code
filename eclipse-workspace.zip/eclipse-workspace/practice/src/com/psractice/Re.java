package com.psractice;

import java.util.Scanner;

public class Re {

	public static void main(String[] args) {
		// 345 reverse it
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number");
		int n = sc.nextInt();
		while(n>0) {
		int	dig=n%10;
			n=n/10;
			System.out.println(dig);
		}
	}

}
