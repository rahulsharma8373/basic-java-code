package com.javatpoint;

public class Student{
	
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	public static void main(String[] args){ 
	Student s=new Student();  
	//setting value in the name member  
	s.setName("vijay");  
	//getting value of the name member  
	System.out.println(s.getName());  
	
	
	
	}	
}