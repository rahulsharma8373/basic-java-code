package oops;

 abstract class Vehicle {
	 
	 abstract void start();
 }
	 
	 class Car extends Vehicle{
	 
	 void start()
	 {
	 System.out.println("start with key");
	 }
	 
	 class Scooter extends Vehicle
	 {
	  void start()
	 {
	 System.out.println("start with kick");
	 }
	public void main(String[] args) {
		// TODO Auto-generated method stub
		 Car c=new Car();
		 c.start();
		 Scooter s=new Scooter();
		 s.start();
		
	 
	 }}}
	 
	 


