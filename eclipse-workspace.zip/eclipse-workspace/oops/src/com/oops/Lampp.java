package com.oops;

public class Lampp {
boolean isOn;
void turnOn() {
	isOn=true;
	System.out.println("light on " + isOn);
}
public static void main(String[] args) {
	Lampp led=new Lampp();
	led.turnOn();
}
}
