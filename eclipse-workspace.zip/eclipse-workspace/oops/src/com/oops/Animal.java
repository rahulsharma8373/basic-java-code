package com.oops;

public class Animal {
public void eat() {
	System.out.println("i am eating");
}
	public static void main(String[] args) {
	System.out.println(1);
Animal buzo = new Animal();


buzo.eat();
buzo.run();
Bird sp = new Bird();
sp.fly();

	}
	public void run() {
		System.out.println("i am running");
	}

}
class Bird{
	public void fly() {
		System.out.println("i am flying");
	}
}
