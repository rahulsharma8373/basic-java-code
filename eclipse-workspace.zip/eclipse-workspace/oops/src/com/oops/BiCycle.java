package com.oops;

public class BiCycle {

	int gear=5;
	public void braking() {
		System.out.println("breaking");
	}
	public static void main(String[] args) {
		
		BiCycle b=new BiCycle();
	int s=	b.gear;
		b.braking();
		System.out.println(s);
}
}
