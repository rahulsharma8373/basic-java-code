package com.oops;
// by using method we can initialize object
public class Animmal {
	String color;
	int age;
	void initObj(String c, int a) {
		color=c;
		age = a;
	}
	void display() {
		System.out.println(color+" "+age);
	}
public static void main(String[] args) {
	Animmal buzo=new Animmal();
	buzo.initObj("black", 20);
	buzo.display();
}
}
