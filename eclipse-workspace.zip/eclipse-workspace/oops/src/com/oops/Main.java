package com.oops;

class Lamp{
	boolean isOn;
	void turnOn() {
		isOn=true;
		System.out.println("light on? " + isOn);
	}
	void turnOff() {
		isOn=false;
		System.out.println("light on? " + isOn);
	}
}
public class Main {
public static void main(String[] args) {
	Lampp led=new Lampp();
	Lampp halogen=new Lampp();
	led.turnOn();
	halogen.turnOff();
}
}
