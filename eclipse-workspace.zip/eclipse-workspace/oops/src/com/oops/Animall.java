package com.oops;
// by using reference variable we can initialize object
public class Animall {
	String color;
	int age;
public static void main(String[] args) {
	Animall buzo=new Animall();
	buzo.color="black";
	buzo.age=10;
	System.out.println(buzo.color+" "+buzo.age);
}
}
