package com.java8;

import java.util.ArrayList;
import java.util.List;


public class BookDAO {
	public List<Book> getBooks() {
List<Book> books = new ArrayList<>();

books.add(new Book());



 

return books;

}
}