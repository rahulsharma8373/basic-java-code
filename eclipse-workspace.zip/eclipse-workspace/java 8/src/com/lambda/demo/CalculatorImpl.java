package com.lambda.demo;

interface Calculator {
	
//	void switchOn();
//	void sum(int input);
	
	

}


public class CalculatorImpl {

	
	
	
public static void main(String[] args) {
	Calculator calculator= () ->System.out.println("Switch on");
	
	
	
}
	
}
