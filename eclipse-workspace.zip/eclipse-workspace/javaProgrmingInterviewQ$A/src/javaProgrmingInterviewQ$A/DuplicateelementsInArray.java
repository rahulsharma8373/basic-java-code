package javaProgrmingInterviewQ$A;

public class DuplicateelementsInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		   // here duplicate is ...>  6 so we have to find this 6
		
		int [] arr= {1,2,4,6,7,6,5,9};    
		for(int i=0;i<arr.length-1;i++) {
			for(int j=i+1;j<arr.length;j++) {
				if(arr[i]==arr[j]) {
					System.out.println("The duplicate element is: "+ arr[j]);
				}
			}
		}

	}

}
