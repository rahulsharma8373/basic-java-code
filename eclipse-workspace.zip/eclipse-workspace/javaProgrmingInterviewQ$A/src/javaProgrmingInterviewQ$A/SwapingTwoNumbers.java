package javaProgrmingInterviewQ$A;

public class SwapingTwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10, b=20;
		System.out.println("Before swaping values are.."+a+"  "+b);

		// logic 1  ---> third variable
		
		int t=a;
		a=b;
	b=t;
		
		//logic--2--->use(+,-)operator)   -->without using third variable
		
		//a=a+b; 
		//b=a-b;
		//a=a-b;
		
		
		
		
		
		System.out.println("After swaping values are.."+a+"  "+b);
		
		
		
		
		
		
	}

}
