package javaProgrmingInterviewQ$A;

public class DisplayOddNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int number=1000000000;
		System.out.println("list of odd numbers from 1 to"+number+":");
		for(int i=1;i<=number;i++) {
			if(i%2!=0) {
				System.out.println(i+" ");
			}
		}
		
		
		
		
		
		

	}

}
