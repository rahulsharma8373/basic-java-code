package javaProgrmingInterviewQ$A;

public class CountOfSumOfDigits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int num=1234;
		int sum=0;
		while(num>0) {
			sum=sum+num%10;  //4
			num=num/10;
		}
		System.out.println("sum of digits in a number:  "+sum);

	}

}
