package javaProgrmingInterviewQ$A;

public class ReverseString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Using + (String concatenation) operator
		String str="ABCD";
		String rev= " ";
	/*	int len=str.length();
		for(int i=len-1;i>=0;i--){
		rev=rev+str.charAt(i);

	}
		*/
		
		
		// using character array
	/*char a[]=str.toCharArray();
	int len=a.length;
		for(int i=len-1;i>=0;i--) {
		rev=rev+a[i];
		}*/
		
		StringBuffer sb=new StringBuffer(str);
		System.out.println(sb.reverse());
 
}
}