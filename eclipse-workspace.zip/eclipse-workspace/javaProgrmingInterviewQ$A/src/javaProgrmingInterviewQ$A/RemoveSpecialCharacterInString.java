package javaProgrmingInterviewQ$A;
                                                       // write a java program to remove all special characters from given Strings
public class RemoveSpecialCharacterInString {          // input---> $ja!va$&st%ar
	                                                    // output---> javastar

	public static void main(String[] args) {                          
		// TODO Auto-generated method stub
String str=" $ja!va$&st%ar";
// approach 1-->(replaceAll() method)

  
str = str.replaceAll("[^a-zA-Z0-9]", " ");  

System.out.println(str); 
		
	}

}
