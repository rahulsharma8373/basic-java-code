package javaProgrmingInterviewQ$A;
                                                                         // input:  ja  va  s  ta   r
                                                                          // output:  javastar
public class RemoveAllWhiteSpacesFromGivenString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str="   ja  va  s  ta   r    ";
		
	String str1=	str.replaceAll("\\s", "");
		System.out.println(str1);
		
		
		
		

	}

}
