package javaProgrmingInterviewQ$A;

public class LinearSearchInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {10,20,40,50,30};
		int search_ele=30;
		boolean flag=false;
		for(int i=0;i<a.length-1;i++) {
			if(search_ele==a[i]) {
				System.out.println("element is found at: "+i);
				flag=true;
				break;
			}
			
		}
if (flag==false) {
	System.out.println("element not found");
}
	}

}
