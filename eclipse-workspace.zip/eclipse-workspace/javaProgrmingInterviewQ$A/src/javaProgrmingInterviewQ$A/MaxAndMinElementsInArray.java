package javaProgrmingInterviewQ$A;

public class MaxAndMinElementsInArray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// int a[]= {50,30,40,20,60};
		/* int max=a[0];  // 50
		 for(int i=1;i<a.length;i++) {
			 if(a[i]>max) { // 30>50
				 max=a[i]; //50
				 
			 }
		 }
System.out.println("maximum elements in array is:"+ max); */



 int a[]= {50,100,40,20,60}; 
		 
int min=a[0]; // 50
for(int i=1;i<a.length;i++) {
	if(a[i]<min) { //100<50
		min=a[i];
		
	}
}
System.out.println(min);

	}

}
