package com.train.booking;

import java.time.LocalDate;
import java.util.LinkedList;
import java.util.List;

public class TrainService {
private static List<Train> allTrains = new LinkedList<>();
private static String numOfSeats;

static {
	allTrains.add(new Train(101,"Train-one","Hyderabad","bangalore",100,800,LocalDate.now()));
	allTrains.add(new Train(102, "Train-two","Bangalore","Hyderabad",100,800,LocalDate.now()));
	allTrains.add(new Train(103, "Train-three","Hyderabad","Bangalore",80,600,LocalDate.now()));
	allTrains.add(new Train(104, "Train-four","Bangalore","Hyderabad",80,600,LocalDate.now()));
	allTrains.add(new Train(105, "Train-five","Hyderabad","Chennai",100,900,LocalDate.now()));
	allTrains.add(new Train(106, "Train-Six","Chennai","Hyderabad",100,900,LocalDate.now()));
	
}

public TrainService() {
	super();
	// TODO Auto-generated constructor stub
}
public static Train findTrain(int trainNumber) {
	Train temp = null;
	for(Train t : allTrains) {
		if(t.getTrainNumber()==trainNumber) {
			temp = t;
			break;
		}
	}
	return temp;
}

public static void searchTrainBetweenStations(String fromStation, String toStation, LocalDate doj, int numofSeats) {
	for(Train t : allTrains) {
		if(t.getFromStation().equals(fromStation) &&
			t.getToStation().equals(toStation) &&
			t.getDoj().equals(doj) &&
			t.getSeatsAvailable() > numOfS) {
             searchTrainList.add(t);

		}
	}
}































}
