
public class NestedIf {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
		/*
int age=20;
int weight = 80;
if(age>18) {
	if(weight>50) {
		System.out.println("you are eligible to donate Blood");
	}
}
*/
int age=25;    
int weight=48;      
//applying condition on age and weight    
if(age>=18){      
    if(weight>50){    
        System.out.println("You are eligible to donate blood");    
    } else{  
        System.out.println("You are not eligible to donate blood");    
    }  
} else{  
  System.out.println("Age must be greater than 18");  
}  
	}

}
