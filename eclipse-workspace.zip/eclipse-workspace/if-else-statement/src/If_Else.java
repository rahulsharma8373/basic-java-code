
public class If_Else {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num=10;
if(num>0) {
	System.out.println("positive number");
}
else {
	System.out.println("not positive");
}
System.out.println("statement outside if block");
	}

}
