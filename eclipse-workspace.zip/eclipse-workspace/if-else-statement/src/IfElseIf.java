
public class IfElseIf {

	public static void main(String[] args) {
	String city = "Delhi";
	if(city=="meerut") {
		System.out.println("city is meerut");
	}else if(city== "noida") {
		System.out.println("city is noida");
	}else if (city== "patna") {
		System.out.println("city is patna ");
	}else {
		System.out.println(city);
	}
		
	}

}
