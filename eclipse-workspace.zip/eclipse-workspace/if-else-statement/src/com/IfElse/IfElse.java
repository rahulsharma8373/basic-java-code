package com.IfElse;

public class IfElse {

	public static void main(String[] args) {
	int a=10;
	int b=12;
	if(a+b<10) {
		System.out.println("a + b is less than   10");
		
	} else {
		System.out.println("a + b is greater than 20");
	}

	}

}
